#include "project.h"
#include "FreeRTOS.h"
#include "task.h"
#include "motion_task.h"
#include "display_task.h"

int main(void)
{
    __enable_irq();

    xTaskCreate(Task_Display, "Display", 1024, NULL, 5, NULL);
    xTaskCreate(Motion_Task, "Motion", 1024, NULL, 6, NULL);

    vTaskStartScheduler();

    for(;;);
}
