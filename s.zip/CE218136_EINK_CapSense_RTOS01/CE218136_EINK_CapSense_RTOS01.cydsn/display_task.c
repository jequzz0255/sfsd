#include "display_task.h"
#include "cy_eink_library.h"
#include "FreeRTOS.h"
#include "task.h"
#include <stdio.h>

QueueHandle_t displayQueue;

void Task_Display(void *pvParameters)
{
    (void)pvParameters;

    display_data_t data;
    char text[128];

    // Tworzymy kolejkę tylko raz
    displayQueue = xQueueCreate(1, sizeof(display_data_t));

    Cy_EINK_Start(25, vTaskDelay);
    Cy_EINK_Power(CY_EINK_ON);
    Cy_EINK_Clear(CY_EINK_WHITE_BACKGROUND, CY_EINK_POWER_MANUAL);

    for(;;)
    {
        if(xQueueReceive(displayQueue, &data, portMAX_DELAY))
        {
            snprintf(text, sizeof(text),
                "ROLL:  %.1f deg\n"
                "PITCH: %.1f deg\n\n"
                "LP:%d  PP:%d\n"
                "LT:%d  PT:%d",
                data.roll_deg, data.pitch_deg,
                data.lp, data.pp, data.lt, data.pt);

            Cy_EINK_TextToScreen(text, CY_EINK_FONT_8X12BLACK);
        }
    }
}