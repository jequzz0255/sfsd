#ifndef DISPLAY_TASK_H
#define DISPLAY_TASK_H

#include "FreeRTOS.h"
#include "queue.h"

/* Dane do wyświetlenia */
typedef struct
{
    float roll_deg;
    float pitch_deg;
    int lp, pp, lt, pt;
} display_data_t;

/* Queue do komunikacji z motion task */
extern QueueHandle_t displayQueue;

/* Task E-INK */
void Task_Display(void *pvParameters);

#endif