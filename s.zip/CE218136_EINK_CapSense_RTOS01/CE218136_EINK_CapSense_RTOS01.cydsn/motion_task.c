#include "motion_task.h"
#include "display_task.h"
#include "bmi160.h"
#include "FreeRTOS.h"
#include "task.h"
#include <math.h>

#define MAXACCEL (32768/2)

/* extern jeśli bmi160Dev jest zdefiniowane w innym pliku */
extern struct bmi160_dev bmi160Dev;

static float roll0 = 0.0f;
static float pitch0 = 0.0f;

static void calculate_angles(float ax, float ay, float az,
                             float *roll, float *pitch)
{
    *roll  = atan2f(ax, sqrtf(ay*ay + az*az));
    *pitch = atan2f(ay, az);
}

void Motion_Task(void *pvParameters)
{
    (void)pvParameters;

    struct bmi160_sensor_data acc;
    display_data_t data;
    int first = 1;

    for(;;)
    {
        bmi160_get_sensor_data(BMI160_ACCEL_ONLY, &acc, NULL, &bmi160Dev);

        float gx = (float)acc.x / MAXACCEL;
        float gy = (float)acc.y / MAXACCEL;
        float gz = (float)acc.z / MAXACCEL;

        float roll, pitch;
        calculate_angles(gx, gy, gz, &roll, &pitch);

        if(first)
        {
            roll0 = roll;
            pitch0 = pitch;
            first = 0;
        }

        data.roll_deg  = (roll - roll0) * 180.0f / M_PI;
        data.pitch_deg = (pitch - pitch0) * 180.0f / M_PI;

        /* przykładowe dane do testu */
        data.lp = 1;
        data.pp = 2;
        data.lt = 0;
        data.pt = 1;

        xQueueOverwrite(displayQueue, &data);

        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}