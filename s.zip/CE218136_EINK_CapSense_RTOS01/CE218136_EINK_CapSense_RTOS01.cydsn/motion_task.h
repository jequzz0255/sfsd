#ifndef MOTION_TASK_H
#define MOTION_TASK_H

#include "FreeRTOS.h"
#include "task.h"

/* Deklaracja taska */
void Motion_Task(void *pvParameters);

#endif